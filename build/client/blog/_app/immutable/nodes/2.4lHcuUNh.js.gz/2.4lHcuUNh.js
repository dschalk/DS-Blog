import{t,a as p}from"../chunks/Cr_1vraW.js";import"../chunks/B-yij5ct.js";var r=t("<h1>David's Blog</h1>");function n(a){var o=r();p(a,o)}export{n as component};
